# Onemon
Pastikan anda telah menginstal compiler prolog untuk bisa menjalankan permainan ini.
Start Permainan dengan cara menjalankan file main.pl dalam compiler prolog.